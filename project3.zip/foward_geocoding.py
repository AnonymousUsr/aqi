import json
import urllib.request
import os

class ForwardGeoCoding:
    '''Class to help with forward geocoding'''
    def __init__(self) -> None:
        '''Realizes the self geolocation object'''
        self.geoLocation = None

    def getGeoLocation(self):
        '''Returns an address'''
        return self.geoLocation

class NominatimGeocoding(ForwardGeoCoding):
    '''Class to connect with the Nominatim API to find latitude and longitude using an address'''
    def __init__(self, address) -> None:
        '''Initializes given address as a self object'''
        self.address = address

    def getGeoLocation(self) -> int|float:
        '''Attempts to connect to the Nominatim API with the given address and
        if a valid response is obtained then returns the latitude and longitude of that address'''
        self.apiUrl = "https://nominatim.openstreetmap.org/search/{}?format=json&addressdetails=1&limit=1".format(self.address)
        self.apiUrl = self.apiUrl.replace(" ", "%20")
        try:
            request = urllib.request.Request(
                self.apiUrl,
                headers = {'Referer': 'https://www.ics.uci.edu/~thornton/ics32a/ProjectGuide/Project3/ewen4'})
            response = urllib.request.urlopen(request)
            data = response.read().decode(encoding = 'utf-8')
        except:
            print("FAILED\n{}\nNETWORK".format(self.apiUrl))
        finally:
            response.close()
        obj = json.loads(data)
        lon = obj[0]['lon']
        lat = obj[0]['lat']
        return lat, lon
        
class FileForwardGeoCoding(ForwardGeoCoding):
    '''Class to find latitude and longitude using a file'''
    def __init__(self, file) -> None:
        '''initializes the file as a self object'''
        self.geoFile = file
    
    def getGeoLocation(self) -> int|float:
        '''Attempts to look through the file and returns the found latitude and longitude'''
        try:
            with open(self.geoFile) as file:
                contents = file.read()
                obj = json.loads(contents)
                lon = obj[0]['lon']
                lat = obj[0]['lat']
                return lat, lon
        except IOError:
            print('FAILED\n{}\nMISSING'.format(os.path.abspath(self.geoFile)))

