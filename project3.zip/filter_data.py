import math

class FilterData:
    '''Contains methods that can filter through given AQI data'''
    def __init__(self, data) -> None:
        '''Initalizes given data as a self object'''
        self.purple_data = data
        pass
    
    def aqi_value(self, concentration: int | float) -> int | float:
        '''Using a given pm2.5 value, translates it into an AQI value'''
        aqi = 0
        if concentration  >= 0 and concentration < 12.1:
            aqi = concentration * 4.1666666
        elif concentration  >= 12.1 and concentration < 35.5:
            aqi = ((concentration-12.1) * 2.103) + 51
        elif concentration  >= 35.5 and concentration < 55.5:
            aqi = ((concentration-35.5) * 2.4623) + 101
        elif concentration  >= 55.5 and concentration < 150.5:
            aqi = ((concentration-55.5) * 0.516333) + 151
        elif concentration  >= 150.5 and concentration < 250.5:
            aqi = ((concentration-150.5) * .99099) + 201
        elif concentration  >= 250.5 and concentration < 350.5:
            aqi = ((concentration-250.5) * .99099) + 301
        elif concentration  >= 350.5 and concentration < 500.5:
            aqi = ((concentration-350.5) * .66044) + 401
        else:
            aqi = 501
        return round(aqi)

    def find_distance(self, pointOne: float, pointTwo: float, distance: int|float) -> bool:
        '''Finds the distance between two points using their latitudes and longitudes and 
        returns if it is greater or less than the given distance'''
        latOne = pointOne[0] / 57.29577951
        latTwo = pointTwo[0] / 57.29577951
        lonOne = pointOne[1] / 57.29577951
        lonTwo = pointTwo[1] / 57.29577951
        if (latOne > 0 and latTwo > 0) or (latOne < 0 and latTwo < 0):
            if latOne < latTwo:
                dlat = latTwo - latOne
                alat = abs(latOne+latTwo)/2
            else:
                dlat = latOne - latTwo
                alat = abs(latOne+latTwo)/2
        else:
            dlat = abs(latOne - latTwo)
            alat = dlat/2
        if lonOne < lonTwo:
            dlon = lonTwo - lonOne
        else:
            dlon = lonOne - lonTwo
        x = dlon * math.cos(alat)
        d = (math.sqrt((x**2) + (dlat**2))) * 3958.8
        if d <= distance:
            return True
        else:
            return False