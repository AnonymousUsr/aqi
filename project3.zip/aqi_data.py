import json
import urllib.request
import os

class AQI_Data():
    '''Class to help obtain AQI data'''
    def __init__(self) -> None:
        '''Initializes init'''
        pass

    def getData(self) -> dict:
        '''Returns data'''
        pass

class PurpleData(AQI_Data):
    '''Class to help find data from Purple Air'''
    def __init__(self, key: str) -> None:
        '''Realizes a given key as a self object'''
        self.key = key

    def getData(self) -> dict:
        '''Attempts to connect to Purple Air and obtain AQI data using the given API key'''
        try:
            request = urllib.request.Request(
                'https://api.purpleair.com/v1/sensors?fields=name%2C%20latitude%2C%20longitude%2C%20pm2.5',
                headers = {'X-API-Key': self.key},
                method = 'GET')
            response = urllib.request.urlopen(request)
            data = response.read().decode(encoding = 'utf-8')
            status = response.status
        except:
            print('FAILED')
        finally:
            try:
                if status == 200:

                    try:
                        obj = json.loads(data)
                        return dict(obj)
                    except ValueError:
                        print('FAILED')
                        print(str(status) + ' ' + request.full_url)
                        print('FORMAT')

                else:
                    print('FAILED')
                    print(str(status) + ' ' + request.full_url)
                    print('NOT 200')

            except:
                print(request.full_url)
                print('NETWORK')

class PurpleFileData(AQI_Data):
    '''Class to find data from a file'''
    def __init__(self, file) -> None:
        '''Initalizes the file as a self object'''
        self.file = file
    def getData(self) -> dict:
        '''Attempts to get the contents of the file and returns it'''
        try:
            with open(self.file) as file:
                contents = file.read()
                obj = json.loads(contents)
                return obj
        except IOError:
            print('FAILED\n{}\nMISSING'.format(os.path.abspath(self.file)))