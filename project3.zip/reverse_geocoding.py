import json
import urllib.request
import os

class ReverseGeocoding:
    '''Class to help with reverse geocoding'''
    def __init__(self) -> None:
        '''Realizes the self geolocation object'''
        self.geoLocation = None

    def getAddress(self):
        '''Returns an address'''
        return self.geoLocation
    

class NominatimReverse(ReverseGeocoding):
    '''Class to connect to the Nominatim API to find an address using latitude and longitude'''
    def __init__(self, lat: int|float, lon: int|float) -> None:
        '''Initializes given latitude and longitudes as self objects'''
        self.lat = lat
        self.lon = lon

    def getAddress(self) -> str:
        '''Attempts to connect to the Nominatim API with given latitudes and longitudes and
        if a valid response is obtained then returns the name of the location'''
        self.apiUrl = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat={lat}&lon={lon}".format(lat = self.lat, lon = self.lon)
        self.apiUrl = self.apiUrl.replace(" ", "%20")
        try:
            request = urllib.request.Request(
                self.apiUrl,
                headers = {'Referer': 'https://www.ics.uci.edu/~thornton/ics32a/ProjectGuide/Project3/ewen4'})
            response = urllib.request.urlopen(request)
            data = response.read().decode(encoding = 'utf-8')
        except:
            print("FAILED\n{}\nNETWORK".format(self.apiUrl))
        finally:
            response.close()
        obj = json.loads(data)
        address = obj['display_name']
        return address

class FileReverseGeoCoding(ReverseGeocoding):
    '''Class to find an address using a file'''
    def __init__(self, file) -> None:
        '''Initializes given file as a self object'''
        self.geoFile = file
    
    def getAddress(self):
        '''Attempts to look through the file and find the display name (location)'''
        try:
            with open(self.geoFile) as file:
                contents = file.read()
                obj = json.loads(contents)
                address = obj['display_name']
                return address
        except IOError:
            print('FAILED\n{}\nMISSING'.format(os.path.abspath(self.geoFile)))
    
    def getLat(self):
        '''Attempts to look through the file and find the latitude'''
        try:
            with open(self.geoFile) as file:
                contents = file.read()
                obj = json.loads(contents)
                lat = obj['lat']
                return lat
        except IOError:
            print('FAILED\n{}\nMISSING'.format(os.path.abspath(self.geoFile)))

    def getLon(self):
        '''Attempts to look through the file and find the longitude'''
        try:
            with open(self.geoFile) as file:
                contents = file.read()
                obj = json.loads(contents)
                lon = obj['lon']
                return lon
        except IOError:
            print('FAILED\n{}\nMISSING'.format(os.path.abspath(self.geoFile)))
    